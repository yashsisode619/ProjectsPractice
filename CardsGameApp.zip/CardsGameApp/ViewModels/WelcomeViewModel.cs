﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace CardsGameApp.ViewModels
{
    public class WelcomeViewModel
    {
        private ObservableCollection<int> playersCount = new ObservableCollection<int>();


        public WelcomeViewModel()
        {
            playersCount.Add(3);
            playersCount.Add(4);
            playersCount.Add(5);
            playersCount.Add(6);
        }

        public ObservableCollection<int> PlayersCount
        {
            get
            {
                return this.playersCount;
            }
        }
    }
}
